﻿import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Ù‡Ø´Ø¯Ø§Ø± MQTT'),
          centerTitle: true,
          actions: const [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Center(
                child: Text(
                  'M',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.red,
                  ),
                ),
              ),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: const [
            _StatusCard(
              title: 'ÙˆØ¶Ø¹ÛŒØª Ø§ØªØµØ§Ù„',
              value: 'Ù‚Ø·Ø¹',
              color: Colors.red,
              icon: Icons.wifi_off,
            ),
            SizedBox(height: 12),
            _StatusCard(
              title: 'Ø¢Ø®Ø±ÛŒÙ† Ù¾ÛŒØ§Ù…',
              value: 'Ù‡Ù†ÙˆØ² Ù¾ÛŒØ§Ù…ÛŒ Ø¯Ø±ÛŒØ§ÙØª Ù†Ø´Ø¯Ù‡ Ø§Ø³Øª',
              color: Colors.blue,
              icon: Icons.message_outlined,
            ),
            SizedBox(height: 12),
            _StatusCard(
              title: 'Ø¢Ø®Ø±ÛŒÙ† Ù‡Ø´Ø¯Ø§Ø±',
              value: 'Ù‡Ø´Ø¯Ø§Ø±ÛŒ Ø«Ø¨Øª Ù†Ø´Ø¯Ù‡ Ø§Ø³Øª',
              color: Colors.orange,
              icon: Icons.notifications_active_outlined,
            ),
            SizedBox(height: 12),
            _StatusCard(
              title: 'ØªØ¹Ø¯Ø§Ø¯ Ù¾ÛŒØ§Ù…â€ŒÙ‡Ø§',
              value: '0',
              color: Colors.teal,
              icon: Icons.countertops_outlined,
            ),
            SizedBox(height: 12),
            _StatusCard(
              title: 'ÙˆØ¶Ø¹ÛŒØª Ø³Ø±ÙˆÛŒØ³',
              value: 'ØºÛŒØ±ÙØ¹Ø§Ù„',
              color: Colors.grey,
              icon: Icons.settings_applications_outlined,
            ),
            SizedBox(height: 12),
            _StatusCard(
              title: 'ÙˆØ¶Ø¹ÛŒØª Ù‡Ø´Ø¯Ø§Ø± ÙØ¹Ø§Ù„',
              value: 'Ù‡ÛŒÚ† Ù‡Ø´Ø¯Ø§Ø±ÛŒ ÙØ¹Ø§Ù„ Ù†ÛŒØ³Øª',
              color: Colors.purple,
              icon: Icons.alarm_off_outlined,
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () {},
          icon: const Icon(Icons.settings),
          label: const Text('ØªÙ†Ø¸ÛŒÙ…Ø§Øª'),
        ),
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  final String title;
  final String value;
  final Color color;
  final IconData icon;

  const _StatusCard({
    required this.title,
    required this.value,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: color.withValues(alpha: 0.12),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    value,
                    style: const TextStyle(fontSize: 15),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

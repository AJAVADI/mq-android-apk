// lib/domain/models/mqtt_settings.dart

class MqttSettings {
  final String broker;
  final int port;
  final String clientId;
  final String username;
  final String password;

  MqttSettings({
    required this.broker,
    required this.port,
    required this.clientId,
    required this.username,
    required this.password,
  });

  // متد برای تبدیل تنظیمات به فرمت قابل ذخیره یا نمایش
  Map<String, dynamic> toMap() {
    return {
      'broker': broker,
      'port': port,
      'clientId': clientId,
      'username': username,
    };
  }
}

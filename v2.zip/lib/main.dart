// lib/main.dart
import 'package:flutter/material.dart';
import 'domain/models/mqtt_settings.dart';
import 'presentation/screens/settings_screen.dart';

void main() {
  runApp(const MqttAlertApp());
}

class MqttAlertApp extends StatelessWidget {
  const MqttAlertApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'همدان MQTT',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
      builder: (context, child) {
        return Directionality(textDirection: TextDirection.rtl, child: child!);
      },
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  // اینجا تنظیمات ذخیره شده رو در حافظه نگه می‌داریم
  MqttSettings? _currentSettings;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مدیریت MQTT'), centerTitle: true),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [_buildStatusCard()],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          // منتظر می‌مونیم تا کاربر تنظیمات رو ذخیره کنه و برگرده
          final result = await Navigator.push<MqttSettings>(
            context,
            MaterialPageRoute(builder: (context) => const SettingsScreen()),
          );

          // اگر تنظیمات جدیدی فرستاده شد، صفحه رو بروزرسانی می‌کنیم
          if (result != null) {
            setState(() {
              _currentSettings = result;
            });
          }
        },
        icon: const Icon(Icons.settings),
        label: const Text('تنظیمات'),
      ),
    );
  }

  Widget _buildStatusCard() {
    final hasSettings = _currentSettings != null;

    return Card(
      elevation: 2,
      child: ListTile(
        leading: Icon(
          Icons.router,
          color: hasSettings ? Colors.green : Colors.blue,
          size: 36,
        ),
        title: const Text(
          'وضعیت اتصال',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          hasSettings
              ? 'پیکربندی شده روی بروکر:\n${_currentSettings!.broker}:${_currentSettings!.port}'
              : 'در حال انتظار برای پیکربندی...',
        ),
        trailing: Icon(
          Icons.circle,
          color: hasSettings ? Colors.green : Colors.grey,
        ),
      ),
    );
  }
}
